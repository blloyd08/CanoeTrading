/* Authors:		Brian Lloyd
 * 				Jeremy Wolf
 * 				Andrew Merz
 * 				Shao-Han Wang
 * Assignment:	Homework 4
 * 
 */

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Stack;

public class tcss343 {

	public static void main(String[] args) throws IOException {
		//Read input
		Integer[][] r = getInput();
//		Canoe.power(r);
//		System.out.println(" ");
		
		//Create return sequence
		Stack<Integer> sequenceBF = new Stack<Integer>();
		Stack<Integer> sequenceDC = new Stack<Integer>();
		Stack<Integer> sequenceDP = new Stack<Integer>();

		//Save start time
		long startTime = System.nanoTime();
		// Run Dynamic Programming Test
		System.out.println("Dynamic");
		System.out.println("Minimum cost: " + Canoe.dynamic(r, sequenceDP));
		System.out.println(sequenceDP);
		//Build analysis string
		// 1 millisecond = 1000000 (10^6) nanoseconds.
		//Save end time
		long endTime = System.nanoTime();
		//Calc duration
		long elapsedTime = endTime - startTime;
		StringBuilder sb = new StringBuilder("Completed in ");
		sb.append(elapsedTime/(1000000.0));
		sb.append(" miliseconds\n");
		System.out.println(sb.toString());
		
		
		startTime = System.nanoTime();
		 //Run Divide and Conquer Programming Test
		 System.out.println("Divide and Conquer");
		 try{
			 System.out.println("Minimum cost: " +Canoe.divideAndConqure(r, sequenceDC));
			 System.out.println(sequenceDC);
		 } catch (StackOverflowError e){
			 System.err.println("Stack overflow");
		 }
		//Build analysis string
			// 1 millisecond = 1000000 (10^6) nanoseconds.
			//Save end time
			endTime = System.nanoTime();
			//Calc duration
			elapsedTime = endTime - startTime;
			StringBuilder sb1 = new StringBuilder("Completed in ");
			sb1.append(elapsedTime/(1000000.0));
			sb1.append(" miliseconds\n");
			System.out.println(sb1.toString());
		
			
			
		startTime = System.nanoTime();
		//Run Brute Force Programming Test
		System.out.println("Brute Force");
		try{
			System.out.println("Minimum cost: " + Canoe.bruteForce(r, sequenceBF));
			System.out.println(sequenceBF);
		} catch (OutOfMemoryError e){
			System.err.println("Not enough memory");
		}
		//Build analysis string
				// 1 millisecond = 1000000 (10^6) nanoseconds.
				//Save end time
				endTime = System.nanoTime();
				//Calc duration
				elapsedTime = endTime - startTime;
				StringBuilder sb2 = new StringBuilder("Completed in ");
				sb2.append(elapsedTime/(1000000.0));
				sb2.append(" miliseconds");
				System.out.println(sb2.toString());
				
		



	}

	public static Integer[][] getInput() {
		String rowLine = null;
		int count = 0;

		// Read in first row line to determine the the size of the 2d array.
		Scanner consoleScanner = new Scanner(System.in);
		rowLine = consoleScanner.nextLine();
		Scanner stringScan = new Scanner(rowLine);

		while (stringScan.hasNext()) {
			count++;
			stringScan.next();

		}

		// Create the 2d array based off of count using assumption of n x n
		// size.

		Integer[][] postTable = new Integer[count][count];

		stringScan = new Scanner(rowLine);

		for (int i = 0; i < count; i++) {
			Integer num = stringScan.nextInt();
			postTable[0][i] = num;
		}
		stringScan.close();
		int row = 1;
		while (consoleScanner.hasNextLine()) {
			rowLine = consoleScanner.nextLine();
			stringScan = new Scanner(rowLine);

			for (int j = 0; j < count; j++) {
				try {
					Integer num = stringScan.nextInt();
					postTable[row][j] = num;
				} catch (InputMismatchException e) {
					postTable[row][j] = null;
					stringScan.next();
				}
			}
			row++;
		}
		stringScan.close();
		consoleScanner.close();
		return postTable;
	}
}
